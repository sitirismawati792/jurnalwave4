import { redirect } from 'next/navigation'

export default function AdminPage() {
  redirect('/halo-jurnal/admin')
}
