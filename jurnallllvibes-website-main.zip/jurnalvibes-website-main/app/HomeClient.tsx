'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { LeftSidebar } from '@/components/layout/LeftSidebar';
import { HeroCarousel } from '@/components/cards/HeroCarousel';
import { NewsCard } from '@/components/cards/NewsCard';
import { PollingWidget } from '@/components/widgets/PollingWidget';
import { ReelsSection } from '@/components/cards/ReelsSection';
import { HalloJurnalBanner } from '@/components/cards/HalloJurnalBanner';
import { Article } from '@/types';
import { DUMMY_ARTICLES } from '@/data/dummyArticles';
import { DUMMY_POLL, DUMMY_REELS } from '@/data/dummyPolls';
import { fetchArticles } from '@/lib/wordpress';

export function HomeClient() {
  const [articles, setArticles] = useState<Article[]>(DUMMY_ARTICLES);

  useEffect(() => {
    async function loadArticles() {
      // 1. Sync from localStorage if present
      if (typeof window !== 'undefined') {
        try {
          const saved = localStorage.getItem('jurnal_wave_articles');
          if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              setArticles(parsed);
            }
          }
        } catch {}
      }

      // 2. Fetch from WordPress if online
      try {
        const data = await fetchArticles();
        if (data && data.length > 0) {
          setArticles(data);
        }
      } catch (err) {
        console.error('Error fetching articles from Supabase:', err);
      }
    }

    loadArticles();

    const handleSync = () => {
      if (typeof window !== 'undefined') {
        try {
          const saved = localStorage.getItem('jurnal_wave_articles');
          if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              setArticles(parsed);
            }
          }
        } catch {}
      }
    };

    window.addEventListener('storage', handleSync);
    window.addEventListener('focus', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('focus', handleSync);
    };
  }, []);

  // Limit feed articles to 5 total on homepage
  const feedArticles = articles.filter(a => !a.isHero).slice(0, 5);

  return (
    <div className="flex-grow w-full max-w-container-max mx-auto px-margin-mobile md:px-6 lg:px-gutter pt-stack-lg pb-4 md:pb-stack-lg flex flex-col md:flex-row gap-gutter relative">
      <LeftSidebar articles={articles} />

      <main className="w-full md:w-3/4 flex flex-col gap-stack-lg pr-0 md:pr-6 lg:pr-12">
        <HeroCarousel articles={articles} />

        {/* Section Heading: Berita Terkini */}
        <div className="flex flex-col gap-1 pt-2">
          <h2 className="text-sm sm:text-base font-bold text-on-surface tracking-wider uppercase">
            BERITA TERKINI
          </h2>
          <div className="w-10 h-[2.5px] bg-primary rounded-full mt-0.5" />
        </div>

        {/* Feed Articles (First 2) */}
        <div className="flex flex-col gap-6">
          {feedArticles.slice(0, 2).map(article => (
            <NewsCard key={article.id} article={article} variant="row" />
          ))}
        </div>

        {/* Polling Widget */}
        <PollingWidget poll={DUMMY_POLL} />

        {/* Remaining Feed Articles (Next 3, total 5) */}
        <div className="flex flex-col gap-6">
          {feedArticles.slice(2, 5).map(article => (
            <NewsCard key={article.id} article={article} variant="row" />
          ))}
        </div>

        {/* "Lihat Semua" Text Link */}
        <div className="my-1 sm:my-2 flex justify-center">
          <Link
            href="/berita"
            className="group inline-flex items-center gap-1.5 sm:gap-2 text-primary hover:text-primary-dark font-bold text-xs sm:text-base tracking-wide transition-colors cursor-pointer py-1.5 sm:py-2"
          >
            <span className="group-hover:underline underline-offset-4">Lihat Semua Berita</span>
            <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform duration-200 group-hover:translate-x-1" />
          </Link>
        </div>

        {/* Hallo Jurnal Wide CTA Banner */}
        <HalloJurnalBanner />

        {/* Reels Section (Limited to 4 items on Homepage) */}
        <ReelsSection reels={DUMMY_REELS} limit={4} />
      </main>
    </div>
  );
}
